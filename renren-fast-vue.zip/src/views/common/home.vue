<template>
  <div class="mod-home">
    <h1>欢迎使用到云后台管理系统</h1>
  </div>
</template>

<script>
  export default {
  }
</script>

<style>
  .mod-home {
    line-height: 1.5;
  }
</style>

